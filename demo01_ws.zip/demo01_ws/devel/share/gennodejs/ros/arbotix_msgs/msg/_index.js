
"use strict";

let Analog = require('./Analog.js');
let Digital = require('./Digital.js');

module.exports = {
  Analog: Analog,
  Digital: Digital,
};
