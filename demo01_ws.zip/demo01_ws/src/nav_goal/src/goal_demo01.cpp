#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <nav_msgs/Odometry.h>
#include <string.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>
#include <cmath>

int main(int argc, char** argv)
{
  ros::init(argc, argv, "nav_move_base");
  ros::NodeHandle node;
  //订阅move_base操作服务器
  actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> ac("move_base",true);

  ros::Publisher odom_pub = node.advertise<nav_msgs::Odometry>("odom", 50);

  ros::Time current_time, last_time;
  current_time = ros::Time::now();

for(double i=-2;i<3;i++)
{
  for(double j=-2;j<3;j++)
 {
  //设置我们要机器人走的几个点。
    geometry_msgs::Point point;
    geometry_msgs::Quaternion quaternion;
    geometry_msgs::Pose pose_list[0];
    
    point.x = i;
    point.y = j;
    point.z = 0.000;
    quaternion.x = 0.000;
    quaternion.y = 0.000;
    quaternion.z = 0.012;
    quaternion.w = 0.999;
    pose_list[0].position = point;
    pose_list[0].orientation = quaternion;
        


  ROS_INFO("Waiting for move_base action server...");
  //等待60秒以使操作服务器可用
  if(!ac.waitForServer(ros::Duration(30)))
  {
    ROS_INFO("Can't connected to move base server");
    return 1;
  }
  ROS_INFO("Connected to move base server");
  ROS_INFO("Starting navigation test");


  //循环通过四个航点

     //初始化航点目标
     move_base_msgs::MoveBaseGoal goal;

     //使用地图框定义目标姿势
     goal.target_pose.header.frame_id = "map";

     //将时间戳设置为“now”
     goal.target_pose.header.stamp = ros::Time::now();

     //将目标姿势设置为第i个航点
     goal.target_pose.pose = pose_list[0];

     //让机器人向目标移动
     //将目标姿势发送到MoveBaseAction服务器
     ac.sendGoal(goal);

    //等1分钟到达那里
    bool finished_within_time = ac.waitForResult(ros::Duration(8));

    //如果我们没有及时赶到那里，就会中止目标
    if(!finished_within_time)
    {
        ac.cancelGoal();
        ROS_INFO("Timed out achieving goal");
    }
    else
    {
        //We made it!
        if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
        {
            ROS_INFO("Goal succeeded!");
        }
        else
        {
            ROS_INFO("The base failed for some reason");
        }
    }
 }
}

 //next, we'll publish the odometry message over ROS接下来，我们将在ROS上发布odometry消息
    nav_msgs::Odometry odom;
    odom.header.frame_id = "odom";

    //set the position
    odom.pose.pose.position.x = 0.0;
    odom.pose.pose.position.y = 0.0;
    odom.pose.pose.position.z = 0.0;
    odom.pose.pose.orientation.x = 0.000;
    odom.pose.pose.orientation.y = 0.000;
    odom.pose.pose.orientation.z = 0.000;
    odom.pose.pose.orientation.w = 1.000;

    //set the velocity
    odom.child_frame_id = "base_link";
    odom.twist.twist.linear.x = 0.0;
    odom.twist.twist.linear.y = 0.0;
    odom.twist.twist.angular.z = 0.0;

    //publish the message
    odom_pub.publish(odom);

  ros::spin();
  ROS_INFO("move_base_square.cpp end...");
  return 0;
}
