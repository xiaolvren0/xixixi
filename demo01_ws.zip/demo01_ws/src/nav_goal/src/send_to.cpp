#include <ros/ros.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <actionlib/client/simple_action_client.h>

typedef actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> MoveBaseClient;

typedef struct _POSE
{
  double X;
  double Y;
  double Z;
  double or_x;
  double or_y;
  double or_z;
  double or_w;
  int flag;
} POSE;

POSE pose0 = {0.0, 0.0, 0.0,  0.0, 0.0, 0.0, 0.0, 0};
POSE pose1 = {-1.397, 2.322, 0.0,  0.0, 0.0, 1.0, 0.01512, 1};
POSE pose2 = {-1.305, -2.045, 0.0,  0.0, 0.0, 1.0, 0.00504, 2};
POSE pose3 = {-1.244, -6.262, 0.0,  0.0, 0.0, -1.0, 0.015808, 3};
POSE pose4 = {4.350, 2.428, 0.0,  0.0, 0.0, -0.0129, 1.0, 4};
POSE pose5 = {4.410, -1.846, 0.0,  0.0, 0.0, -0.0181, 1.0, 5};
POSE pose6 = {4.392, -6.482, 0.0,  0.0, 0.0, 0.0, 1.0, 6};

POSE pose10 = {-0.081, -6.411, 0.0,  0.0, 0.0, -0.70165, 0.71252, 0};
POSE pose11 = {1.631, 7.067, 0.0,  0.0, 0.0, 0.007885, 1.0, 1};
POSE pose12 = {3.227, -6.515, 0.0,  0.0, 0.0, 0.708885, 0.705324, 2};
POSE pose13 = {3.239, 1.791, 0.0,  0.0, 0.0, 0.70494, 0.70926, 3};
POSE pose14 = {1.509, 2.791, 0.0,  0.0, 0.0, -1.0, 0.00554, 4};
POSE pose15 = {-0.165, 1.994, 0.0,  0.0, 0.0,  -0.701651, 0.71252, 5};

POSE poseT1 = {-0.057, -6.349, 0.0,  0.0, 0.0, -0.7019, 0.7122, 1};
POSE poseT2 = {2.993, -6.251, 0.0,  0.0, 0.0, 0.6997, 0.7145, 2};
POSE poseT3 = {2.996, 1.782, 0.0,  0.0, 0.0, 0.7044, 0.7098, 3};
POSE poseT4 = {0.009, 1.856, 0.0,  0.0, 0.0, -0.7111, 0.7031, 4};


void setGoal(POSE pose)
{
  ROS_INFO("准备出发去目标 %d", pose.flag);
  //tell the action client that we want to spin a thread by default 
  MoveBaseClient ac("move_base", true); 
  //wait for the action server to come up 
  while(!ac.waitForServer(ros::Duration(5.0))){ 
      ROS_WARN("Waiting for the move_base action server to come up"); 
  }   

  move_base_msgs::MoveBaseGoal goal; 

  //we'll send a goal to the robot to move 1 meter forward 
  goal.target_pose.header.frame_id = "map"; 
  goal.target_pose.header.stamp = ros::Time::now(); 
  goal.target_pose.pose.position.x = pose.X;
  goal.target_pose.pose.position.y = pose.Y; 
  goal.target_pose.pose.position.z = pose.Z;  
  goal.target_pose.pose.orientation.x = pose.or_x;
  goal.target_pose.pose.orientation.y = pose.or_y;
  goal.target_pose.pose.orientation.z = pose.or_z;
  goal.target_pose.pose.orientation.w = pose.or_w;  

  ROS_INFO("发送目标 %d", pose.flag); 
  ac.sendGoal(goal); 
  ac.waitForResult(); 

  if(ac.getState() == actionlib::SimpleClientGoalState::SUCCEEDED) 
  {
    // ROS_INFO("it is successful"); 
    ROS_INFO("已到达目标 %d", pose.flag); 
    // ros::Duration(1.0);
  }  
  else 
    ROS_ERROR("无法到达目标 %d!!", pose.flag);  
}

void ChooseGoal(char *k)
{
  if(*k == '0')  setGoal(pose0);
  else if (*k == '1')  setGoal(pose1);
  else if (*k == '2')  setGoal(pose2);
  else if (*k == '3')  setGoal(pose3);
  else if (*k == '4')  setGoal(pose4);
  else if (*k == '5')  setGoal(pose5);
  else if (*k == '6')  setGoal(pose6);
  else if (*k == 't') //巡回模式
  {
    ROS_INFO("开始巡游超市！");
    for(int i=0; i<2 ;i++){
      setGoal(poseT1);
      setGoal(poseT2);
      setGoal(poseT3);
      setGoal(poseT4);
      ROS_INFO("巡游一次！");
    }
  }

}

int main(int argc, char** argv)
{
  setlocale(LC_ALL,"");
  ros::init(argc, argv, "send_goals");

  if(argc > 1)
  {
    std::cout<<"argc="<<argc<<std::endl;
    for(int i=1; i<argc; i++)
    {
      std::cout<<"argv["<<i<<"] "<<argv[i]<<std::endl;
      // ROS_INFO("%s", argv[i]);
    }

    if(argc == 2)
      ChooseGoal(argv[1]);
    
    else if(argc > 2)
    {
      ROS_INFO("需前往%d个目标！", argc-1);
      for(int i=1; i<argc; i++)
      {
        ROS_INFO("前往第%d个目标点！地点数字：%s", i, argv[i]);
        ChooseGoal(argv[i]);
        ROS_INFO("已到达第%d个目标点！地点数字：%s", i, argv[i]);
        ros::Duration(1.0);
      }
    }
    ROS_INFO("完成导航任务！");
      
  }

  return 0;
}