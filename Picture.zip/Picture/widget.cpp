#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
//    setWindowTitle("导购机器人面板");

    ui->setupUi(this);
    picID = 2;

    ui->textBrowser->setText("金枕头榴莲肉450g/盒，2盒99元，3盒139元。新鲜美味，超值优惠，快来抢购吧！");
    QPixmap pix("/home/rosnoetic/QT_test/recommend_picture/1.png");
    ui->label->setPixmap(pix);

}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_startButton_clicked()
{
    //开启定时器，返回定时器编号
    myTimerId = this->startTimer(TIMEOUT);
}

void Widget::timerEvent(QTimerEvent *event)
{
    QString textstring1 = "金枕头榴莲肉450g/盒，2盒99元，3盒139元。新鲜美味，超值优惠，快来抢购吧！";
    QString textstring2 = "正宗椰树椰汁，330ml*24瓶装。新鲜椰子肉鲜榨，八折促销一箱112元。";
    QString textstring3 = "卫龙辣条大面筋102g,经典透明老包装麻辣儿时怀旧小吃零食休闲食品。三袋9.9元优惠促销！ ";
    QString textstring4 = "小鸡打篮球玩具摆件，两个礼盒装18.8元，双倍快乐！";
    QString textstring5 = "超强力迷你电蚊拍，usb充电，2023新款特价16.9元。";

    if(event->timerId() != myTimerId)
        return;

    QString path("/home/rosnoetic/QT_test/recommend_picture/");
    path += QString::number(picID);

    path += ".png";

    QPixmap pix(path);
    ui->label->setPixmap(pix);
    if (picID == 1)
        ui->textBrowser->setText(textstring1);
    else if(picID == 2)
        ui->textBrowser->setText(textstring2);
    else if(picID == 3)
        ui->textBrowser->setText(textstring3);
    else if(picID == 4)
        ui->textBrowser->setText(textstring4);
    else if(picID == 5)
        ui->textBrowser->setText(textstring5);

    picID++;
    if (6 == picID)
        picID = 1;
}

void Widget::on_stopButton_clicked()
{
    this->killTimer(myTimerId);
}

void Widget::on_overButton_clicked()
{
    QMessageBox::information(this,
        tr("自助结账"),
        tr("请将物品对准平台上的扫码口，进行扫码结账。欢迎您下次惠顾！"),
        QMessageBox::Ok ,
        QMessageBox::Ok);
}

void Widget::on_oneButton_clicked()
{
    system("gnome-terminal -- bash -c 'source ~/demo01_ws/devel/setup.bash; rosrun nav_goal send_to 1'&");
}

void Widget::on_twoButton_clicked()
{
    system("gnome-terminal -- bash -c 'source ~/demo01_ws/devel/setup.bash; rosrun nav_goal send_to 2'&");
}

void Widget::on_threeButton_clicked()
{
    system("gnome-terminal -- bash -c 'source ~/demo01_ws/devel/setup.bash; rosrun nav_goal send_to 3'&");
}

void Widget::on_fourButton_clicked()
{
    system("gnome-terminal -- bash -c 'source ~/demo01_ws/devel/setup.bash; rosrun nav_goal send_to 4'&");
}

void Widget::on_fiveButton_clicked()
{
    system("gnome-terminal -- bash -c 'source ~/demo01_ws/devel/setup.bash; rosrun nav_goal send_to 5'&");
}

void Widget::on_sixButton_clicked()
{
    system("gnome-terminal -- bash -c 'source ~/demo01_ws/devel/setup.bash; rosrun nav_goal send_to 6'&");
}

void Widget::on_routeButton_clicked()
{
    system("gnome-terminal -- bash -c 'source ~/demo01_ws/devel/setup.bash; rosrun nav_goal send_to t'&");
}

void Widget::on_route2Button_clicked()
{
    system("gnome-terminal -- bash -c 'source ~/demo01_ws/devel/setup.bash; rosrun nav_goal send_to 1 3 6'&");
}

void Widget::on_route3Button_clicked()
{
    system("gnome-terminal -- bash -c 'source ~/demo01_ws/devel/setup.bash; rosrun nav_goal send_to 4 5'&");
}
