#ifndef WIDGET_H
#define WIDGET_H

#define TIMEOUT 1*2000

#include <QWidget>
#include <QMessageBox>

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    virtual void timerEvent(QTimerEvent *event);
    ~Widget();

private slots:
    void on_startButton_clicked();

    void on_stopButton_clicked();

    void on_overButton_clicked();

    void on_oneButton_clicked();
    
    void on_twoButton_clicked();
    
    void on_threeButton_clicked();
    
    void on_fourButton_clicked();
    
    void on_fiveButton_clicked();
    
    void on_sixButton_clicked();
    
    void on_routeButton_clicked();
    
    void on_route2Button_clicked();
    
    void on_route3Button_clicked();
    
private:
    Ui::Widget *ui;
    int myTimerId;
    int picID;

};
#endif // WIDGET_H
